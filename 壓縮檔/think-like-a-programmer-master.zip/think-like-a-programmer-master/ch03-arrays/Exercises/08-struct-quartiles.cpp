#include <iostream>
#include <vector>
#include <string>

/*
 * Write a program that processes an array of student objects and determines
 * the grade quartiles�that is, the grade one would need to score as well as or
 * better than 25% of the students, 50% of the students, and 75% of the students.
 */
int main(){
    //
}
