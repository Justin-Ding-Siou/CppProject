#include <iostream>
#include <vector>
#include <string>

/*
 * Write a program that is given an array of integers and determines the mode,
 * which is the number that appears most frequently in the array
 */
int main(){
    //
}
