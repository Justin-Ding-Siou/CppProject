#include <iostream>
#include <vector>
#include <string>

/*
 * Consider this modification of the sales array: Because salespeople come and
 * go throughout the year, we are now marking months prior to a sales agent�s
 * hiring, or after a sales agent�s last month, with a �1. Rewrite your highest
 * sales average, or highest sales median, code to compensate.
 */
int main(){
    //
}
