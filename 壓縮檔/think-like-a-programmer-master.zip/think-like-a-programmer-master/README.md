# Think Like a Programmer Scripts

I created several scripts based on the problems and exercises in the book [Think Like a Programmer](https://www.amazon.com/Think-Like-Programmer-Introduction-Creative/dp/1593274246).
