/*
*   Exercise 4-1
*
*   Design your own: Take a problem that you already know how to solve using
*   an array but that is limited by the size of the array. Rewrite the code to
*   remove that limitation using a dynamically allocated array.
*/

#include<iostrea>

int main()
{

}
